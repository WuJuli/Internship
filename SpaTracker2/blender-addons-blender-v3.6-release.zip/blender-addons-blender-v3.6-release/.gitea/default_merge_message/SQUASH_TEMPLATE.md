${PullRequestTitle}

Pull Request: https://projects.blender.org/blender/blender-addons/pulls/${PullRequestIndex}
