This repository is only used as a mirror. Blender development happens on projects.blender.org.

To get started with contributing code, please see:
https://wiki.blender.org/wiki/Process/Contributing_Code
