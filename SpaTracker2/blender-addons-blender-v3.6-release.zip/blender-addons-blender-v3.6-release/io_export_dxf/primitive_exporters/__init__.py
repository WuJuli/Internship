# SPDX-License-Identifier: GPL-2.0-or-later

"""
This package contains actual primitive exporter classes.
They are imported and instantiated according object type
that is being exported from export_dxf.py in ../

NOTE: Only MESH exporter has been ported since it is imho
mostly used. I am not specialist on Autocad so I cannot
guest how many time the other primitive are used. That's
why they are left unported.
"""
